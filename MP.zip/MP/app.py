from services.run_web import app

if __name__ == "__main__":
    app.run()