"""
حزمة إعدادات الخدمات القانونية
"""

from .services_config import (
    SERVICE_TYPES,
    LEGAL_DISCLAIMER,
    DISCLAIMERS,
    CONTRACT_SECTIONS,
    MEMO_SECTIONS,
    OBJECTION_SECTIONS
)

__all__ = [
    'SERVICE_TYPES',
    'LEGAL_DISCLAIMER',
    'DISCLAIMERS',
    'CONTRACT_SECTIONS',
    'MEMO_SECTIONS',
    'OBJECTION_SECTIONS'
]
